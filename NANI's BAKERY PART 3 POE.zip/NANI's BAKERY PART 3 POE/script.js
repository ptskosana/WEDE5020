function searchMenu() {
    let input = document.getElementById("searchBar").value.toLowerCase();
    let items = document.querySelectorAll(".item");

    items.forEach(item => {
        if (item.textContent.toLowerCase().includes(input)) {
            item.style.display = "block";
        } else {
            item.style.display = "none";
        }
    });
}

function calculatePrice() {
    let price = document.getElementById("product").value;
    let quantity = document.getElementById("quantity").value;

    let total = price * quantity;

    document.getElementById("result").innerHTML =
        "Estimated Cost: R" + total;
}

function openLightbox(src) {
    document.getElementById("lightbox").style.display = "block";
    document.getElementById("lightboxImg").src = src;
}

function closeLightbox() {
    document.getElementById("lightbox").style.display = "none";
}

document.addEventListener("DOMContentLoaded", function () {

    const contactForm = document.getElementById("contactForm");

    if (contactForm) {
        contactForm.addEventListener("submit", function (e) {

            e.preventDefault();

            alert("Message submitted successfully!");

        });
    }

});